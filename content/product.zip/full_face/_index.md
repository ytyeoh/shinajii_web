---
title: "full face"
date: 2017-03-23
publishdate: 2017-03-24

type: "images/helmet/c1.png"
aa: "images/main_page/full_face/a1.png"  
bb: "images/main_page/full_face/a2.png"  
cc: "images/main_page/full_face/a3.png"
layout: list

---

I decided to start learning Go in March 2017.

Follow my journey through this new blog.