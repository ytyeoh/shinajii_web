---
title : "donation"
layout: "donate"
description: "Technologies is about advancement, and innovation is to come out with something original and unique, and MHR is combining this tow terms together, to make high quality and affordable helmet for all motorcycle riders."
image : "images/donate/1.png"


desc:
  - title: 'A) Supporting a birthing family'
    desc: 'US$500 can support a family with: <br>Education and care during pregnancy, Labour support, Transportation to hospital, Partial subsidy of hospital costs, A baby pack containing baby care items and Postnatal support '
  - title: 'B) Supporting a child to receive education'
    desc: 'US$25 per month/ $300 per year can support a child in elementary education'
  - title: 'C) Joining our team and volunteer your services'
    desc: '<ol><li>Education field.</li><li>Social welfare services</li><li>Midwifery/doula skills (or the willingness to be trained in these skills) </li><ol>'

---
