---
title : "testimonials"
layout: "testimonials"
description: "Technologies is about advancement, and innovation is to come out with something original and unique, and MHR is combining this tow terms together, to make high quality and affordable helmet for all motorcycle riders."
image : "images/helmet/b1.png"
banner:
  slide: 
    - image : 'images/testimonials/T1.png'
    - image : 'images/testimonials/T2.png'
    - image : 'images/testimonials/T3.png'
    - image : 'images/testimonials/T4.png'
    - image : 'images/testimonials/T5.png'
    - image : 'images/testimonials/T6.png'
    - image : 'images/testimonials/T7.png'
    - image : 'images/testimonials/T8.png'
    - image : 'images/testimonials/T9.png'
    - image : 'images/testimonials/T10.png'

teams:
  enable : true
  title : 'Our Team Members'
  name : "Glyn"
  pose : "Midwife/Doula"
  img : 'images/teams/1.png'
  position : 'left'
  members:
  - name : "Lynne"
    pose : "Educator/<br>Doula Assistant"
    img : 'images/teams/2.png'
    position : 'right'
  - name : "Ashley"
    pose : "Midwife/Doula"
    img : 'images/teams/3.png'
    position : 'left'
  - name : "Staci"
    pose : "Trainee Doula/<br>Team Builder"
    img : 'images/teams/4.png'
    position : 'right'
  - name : "Dee"
    pose : "Translator/<br>Assistant Doulaa"
    img : 'images/teams/5.png'
    position : 'left'
  - name : "Sadia"
    pose : "Translator/<br>Assistant"
    img : 'images/teams/6.png'
    position : 'right'


---