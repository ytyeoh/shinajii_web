---
title : "donation"
layout: "donation"
description: "Technologies is about advancement, and innovation is to come out with something original and unique, and MHR is combining this tow teUSD s together, to make high quality and affordable helmet for all motorcycle riders."
image : "images/donate/1.png"


one:
  - amount: "USD 20"
    url: "https://donate.stripe.com/dR68zY5sacrvdI43cr"
  - amount: "USD 50"
    url: "https://book.stripe.com/fZe9E21bU9fj1Zm14k"
  - amount: "USD 100"
    url: "https://book.stripe.com/aEUg2q4o69fj8nK8wN"
  - amount: "USD 250"
    url: "https://donate.stripe.com/8wM5nMdYG4Z3avSbJ0"
  - amount: "USD 500"
    url: "https://donate.stripe.com/14k8zY8Em3UZavS14n"
  - amount: "Any Amounts"
    url: "https://donate.stripe.com/7sIdUiaMu4Z333q4gA"
monthly:
  - amount: "USD 20"
    url: "https://buy.stripe.com/7sI9E25sabnrfQc28i"
  - amount: "USD 50"
    url: "https://buy.stripe.com/8wMeYm8EmgHL9rOaEP"
  - amount: "USD 100"
    url: "https://buy.stripe.com/cN26rQg6Oajn8nK3cl"
  - amount: "USD 250"
    url: "https://buy.stripe.com/fZe4jIaMu3UZeM83co"
  - amount: "USD 500"
    url: "https://buy.stripe.com/8wM8zY7Ai2QVcE0dR3"
  - amount: "Any Amounts"
    url: "https://buy.stripe.com/aEU7vU4o6ezDgUg14i"
---
