---
title: "flip up"
date: 2017-03-23
publishdate: 2017-03-24

type: "images/helmet/c1.png"
layout: list
aa: "images/main_page/flip_up/b1.png"  
bb: "images/main_page/flip_up/b2.png"  
cc: "images/main_page/flip_up/b3.png"

---

I decided to start learning Go in March 2017.

Follow my journey through this new blog.